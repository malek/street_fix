package com.example.street_fix

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
