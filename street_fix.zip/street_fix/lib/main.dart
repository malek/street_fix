import 'package:flutter/material.dart';
import 'package:street_fix/screens/recordShow.dart';

void main() => runApp(
  MaterialApp(
    debugShowCheckedModeBanner: false,
  //initialRoute: '/home',

  routes:  {
    //'/': (context) => FormScreen(),
    '/':  (context) => RecordShow(),
    
  } ,
  //home: Welcome(),
));
// class Welcome extends StatefulWidget {
//   @override
//   _WelcomeState createState() => _WelcomeState();
// }

// class _WelcomeState extends State<Welcome> {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('lol'),
//       ),
//       body: Text('lolll'),

//     );
//   }
// }
