//import 'dart:async';

import 'package:flutter/material.dart';
import 'package:sensors/sensors.dart';


class RecordShow extends StatefulWidget {
  @override
  _RecordShowState createState() => _RecordShowState();
}

class _RecordShowState extends State<RecordShow> {
  String recordresult='';
  String buttonText ='record';
double x, y, z;
  //column for x y z
  Column results = new Column();
   @override
  void initState() {
    // TODO: implement initState
    super.initState();
    accelerometerEvents.listen((AccelerometerEvent event) {
      setState(() {
        x = event.x;
        y = event.y;
        z = event.z;
      });
    }); //get the sensor data and set then to the data types
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Street Fix'),
        centerTitle: true,
        backgroundColor: Colors.grey[900],
      ),
      body: Column(children: <Widget>[
        Container(color: Colors.black, child : results),
        RaisedButton(child: Text(buttonText),onPressed: (){
          setState(() {
            buttonText= 'Done';
            results = Column( children: <Widget>[
              
          Text('x= ${x.toStringAsFixed(2)}'),
          Text('y= ${y.toStringAsFixed(2)}'),
          Text('z= ${z.toStringAsFixed(2)}'),
          //Text('x: ${(event?.x ?? 0).toStringAsFixed(3)}'),
          //Text('z: ${(event?.z ?? 0).toStringAsFixed(3)}'),
            ]
        );
        setState(() {
          
        });
          });
        })
      ],)
    );
  }
}
